#Mehrdad Moghadam

String = input("Please Enter A Sentences : " )
String = String.lower()
String = String.replace(" " , "")

counter = dict()

for word in String:
    if word in counter:
        counter[word] += 1
    else:
        counter[word] = 1

for i in counter.keys():
    print(i + " " + ":" + " " + str(counter[i]))

