#Mehrdad Moghadam

String = input("Enter A Sentences : ")

i = String.split(' ')


String_output =''

for harf in i :
    if harf[0].islower():
        String_output += harf[::-1]
    else:
        String_output += harf
    String_output +=' '

print(String_output)
