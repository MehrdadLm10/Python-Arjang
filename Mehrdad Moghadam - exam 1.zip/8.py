String = input("Enter A Sentences : ")

if String == String[::-1] :
    print("True")

else :
    print("False")
