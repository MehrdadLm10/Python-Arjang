X = input("Enter A Number : ")

if len(X) < 100 :
    for i in X :
        i = int(i)
        print(str(i) + ":" + str(i)*i)
