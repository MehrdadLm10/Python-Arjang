Tedad_Daneshjoo = int(input("Enter the quantity of students: "))
Tedad_Dars = int(input("Enter the quantity of marks: "))

Dict_List = []

for i in range(Tedad_Daneshjoo):
    Dict_List_Nomarat = []
    Name = input("Enter a Name: ")
    Student_Number = int(input("Enter a Student_Number: "))
    for j in range(Tedad_Dars):
       Dict_List_Nomarat.append(int(input("Enter a mark: ")))
    Mark = 0
    for j in Dict_List_Nomarat:
        Mark += j
    Mark = Mark / len(Dict_List_Nomarat)
    print(" ")
    Dict_List.append({"Name" : Name,"Student_Number" : Student_Number,"Mark" : Mark})

num = 0
std_num = 0
max_num = Dict_List[0]["Mark"]

for i in Dict_List:
    if i["Mark"] > max_num: 
        std_num = num
        max_num = i["Mark"]
    num += 1
for n in Dict_List:
    if n["Mark"] == max_num:
        print("Max Num is: " + str(n["Mark"]) + " From " + n["Name"] + " ( " + str(n["Student_Number"]) + " )")








