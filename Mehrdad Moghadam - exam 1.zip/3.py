String = input("Please Enter A Sentences : ")

Dict = {}

def string_smallest(String):
    Dict = {"LOWER_CASE":0}
    for word in String:
        if word.islower():
           Dict["LOWER_CASE"] += 1
    print("Number of Lower case Characters : " , Dict["LOWER_CASE"])


def string_bigger(String):
    Dict = {"UPPER_CASE":0}
    for word in String:
        if word.isupper():
           Dict["UPPER_CASE"] += 1
    print("Number of Upper case Characters : " , Dict["UPPER_CASE"])



def string_sedadar(String) :
    String = String.lower()
    List = ["a" , "e" , "i" , "o" , "u"]
    Dict = {"SEDA_DAR" : 0}
    for word in String :
        if word in List:
            Dict["SEDA_DAR"] += 1
    print("Number of seddar Characters : " , Dict["SEDA_DAR"])


def string_number(String) :
    Dict = {"NUMBER_CASE":0}
    for word in String :
        if word.isdigit() :
            Dict["NUMBER_CASE"] += 1
    print("Number of Numbers Characters : " , Dict["NUMBER_CASE"])
        


    
string_smallest(String)
string_bigger(String)
string_sedadar(String)
string_number(String)
