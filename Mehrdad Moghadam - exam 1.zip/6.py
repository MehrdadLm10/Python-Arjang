Num = int(input("Enter A Number : " ))

for i in range (0 , Num) :
    Num = 1
    
    for j in range (0 , i+1) :
        print(Num , end = " ")
        Num += 1

    print("\r")
