Blood = input("Enter Your Group Of Blood : ")

Blood = Blood.upper()

if Blood == "O-" :
    print("O- O+ A+ A- B+ B- AB+ AB-")
elif Blood == "O+" :
    print("O+ A+ B+ AB+")
elif Blood == "A+" :
    print("A+ AB+")
elif Blood == "B+" :
    print("B+ AB+")
elif Blood == "AB+" :
    print("AB+")
elif Blood == "A-" :
    print("A- A+ AB- AB+")
elif Blood == "B-" :
    print("B- B+ AB+ AB-")
elif Blood == "AB-" :
    print("AB- AB+")
else:
    print("OUT OF GROUP BLOOD")
