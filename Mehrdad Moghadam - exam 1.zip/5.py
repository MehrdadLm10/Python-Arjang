Num = int(input("Enter A Number : "))

for i in range(Num+1,0,-1) :
    for j in range(0 , i-1) :
        print("*" , end = "")

    print("\r")
