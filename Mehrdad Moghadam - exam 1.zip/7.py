Hoghoogh = int(input("Enter Your Salary : "))

if 0<=Hoghoogh<500 :
    print(Hoghoogh)
elif 500<=Hoghoogh<1000 :
    Maliat = 0.1
    Hoghoogh_kol = Hoghoogh * Maliat
    print(int(Hoghoogh_kol))
elif 1000<=Hoghoogh<3000 :
    Maliat = 0.2
    Hoghoogh_Kol = Hoghoogh * Maliat
    print(int(Hoghoogh_Kol))
elif 3000<=Hoghoogh<5000 :
    Maliat = 0.3
    Hoghoogh_Kol = Hoghoogh * Maliat
    print(int(Hoghoogh_Kol))
elif 5000<=Hoghoogh<10000 :
    Maliat = 0.4
    Hoghoogh_Kol = Hoghoogh * Maliat
    print(int(Hoghoogh_Kol))
elif Hoghoogh>=10000 :
    Maliat = 0.5
    Hoghoogh_Kol = Hoghoogh * Maliat
    print(int(Hoghoogh_Kol))
else :
    print("OUT OF RANGE.")
