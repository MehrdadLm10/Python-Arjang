Years = int(input("Enter One Year : "))

while True :
    right_Number = 1
    Years = Years + 1
    for n in str(Years) :
        if str(Years).count(n) > 1 :
            right_Number = 0
            break
    if right_Number == 1 :
         break

print(Years)
