'''MEHRDAD MOGHADAM'''

import subprocess as Sub

def Menu_List() :
    print("Option 1 : Cmd. ")
    print("Option 2 : Ping. ")
    print("Option 3 : Drivers Of System. ")
    print("Option 4 : File. ")
    print("Option 5 : Delete File. ")

while True:
    Menu_List()
    choice = input("Enter Your Option : ")

    if choice == "1" :
        print("You Choose Option 1. ")
        Command = input("Enter Your Command : ")
        cmd = Sub.check_output(Command , shell=True).decode()
        print(cmd)

    elif choice == "2" :
        print("You Choose Option 2. ")
        IP = input("Enter Your IP : ")
        cmd = Sub.check_output("ping -n 3 "+IP, shell=True).decode()
        print(cmd)
        print()
        print("-------------------------")
        print()

    elif choice == "3" :
        print("You Choose Option 3. ")
        sys_drives = []
        drives = ["A:" , "B:" , "C:" , "D:" , "F:" , "E:" , "H:" , "G:" , "Z:" , "I:"]

        cmd = Sub.check_output("net share" , shell=True).decode()

        for i in drives :
            if i in str(cmd) :
                sys_drives.append(i)

        print(sys_drives)

    elif choice == "4" :
        print("You Choose Option 4. ")

        sys_drives = []
        drives = ["A:" , "B:" , "C:" , "D:" , "F:" , "E:" , "H:" , "G:" , "Z:" , "I:"]

        cmd = Sub.check_output("net share", shell=True).decode()

        for i in drives:
            if i in str(cmd):
                sys_drives.append(i)

        File = input("Enter Your File Name : ")

        for i in sys_drives :
            try:
                cmd = Sub.check_output("dir / S /B" + i + "\\" + File, shell=True).decode()
            except  Sub.CalledProcessError:
                pass
        print(cmd)

    elif choice == "5" :
        print("You Choose Option 5. ")

        sys_drives = []
        drives = ["A:" , "B:" , "C:" , "D:" , "F:" , "E:" , "H:" , "G:" , "Z:" , "I:"]

        cmd = Sub.check_output("net share", shell=True).decode()

        for i in drives:
            if i in str(cmd):
                sys_drives.append(i)

        File = input("Enter Your File Name : ")

        for i in sys_drives:
            try:
                cmd = Sub.check_output("del /S "+i+"\\"+File, shell=True).decode()
            except Sub.CalledProcessError:
                pass
        print(cmd)

    else :
        print("OUT OF RANGE !!")






