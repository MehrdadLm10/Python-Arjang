string = "Python Is a Programming Language"
print("is : " , "is" in string)
print("Is : " , "Is" in string)
print("Programming : " , "programming" in string)
print("programming : " , "Programming" in string)
print("python : " , "Python" in string)
