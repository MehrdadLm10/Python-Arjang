x = "python programming"
y = input("Enter a String: ")
print(len(x) == len(y))
