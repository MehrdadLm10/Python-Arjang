First_Name = input("Enter Your First Name: ")
Last_Name = input("Enter Your Last Name: ")
print("Your First Name: " , First_Name)
print("Your Last Name: " , Last_Name)