''' MEHRDAD MOGHADAM'''

from telegram.ext import Updater , CommandHandler

token = Updater('1946342124:AAFchTOQvRf1O57cosNRhiiP-X3nJhiqIBQ',use_context=True)

def start(update,context):
    context.bot.send_message(text='سلام به ربات سايت ديجيکالا خوش آمديد. \n برای اطلاعات بیشتر روی دستور /help   کلیک نمایید',chat_id=update.message.chat_id)

def website(update,context):
    context.bot.send_message(chat_id= update.message.chat_id , text= 'وبسایت ما : \n https://www.digikala.com')
def help (update,context):
    context.bot.send_message(chat_id= update.message.chat_id , text= 'برای دریافت ادرس وب سایت ما از دستور /website  استفاده کنید \n برای شروع مجدد ربات از /start  استفاده نمایید.')

token.dispatcher.add_handler(CommandHandler('start',start))
token.dispatcher.add_handler(CommandHandler('website',website))
token.dispatcher.add_handler(CommandHandler('help' , help))

token.start_polling()
token.idle()
