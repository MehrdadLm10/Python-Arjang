from telegram.ext import Updater , CommandHandler , MessageHandler , Filters
from telegram import ParseMode , MessageEntity

token = Updater('1946342124:AAFchTOQvRf1O57cosNRhiiP-X3nJhiqIBQ' , use_context=True)

def start1(update , context):
    context.bot.send_message(chat_id= update.message.chat_id , text= 'سلام{} به ربات ضد لینک سايت ديجيکالا خوش آمديد.\n برای اطلاعات بیشتر روی دستور /help   کلیک نمایید'.format(update.message.from_user.first_name))
    context.bot.send_message(chat_id= update.message.chat_id , text= 'id : {} \n user : {} \n firstname : {}'.format(update.message.chat_id , update.message.from_user.username ,update.message.from_user.first_name ))
    print(update.message)
def website(update , context):
    context.bot.send_message(chat_id= update.message.chat_id , text= 'وبسایت ما :\n https://www.digikala.com')
def help1 (update , context):
    context.bot.send_message(chat_id= update.message.chat_id , text= 'برای دریافت ادرس وب سایت ما از دستور /website  استفاده کنید \n برای شروع مجدد ربات از /start  استفاده نمایید.\n برای دسترسی به پنل ادمین از دستور /admin  استفاده کنید. ')
def admin (update , context):
    if update.message.chat_id != 111538566:
        context.bot.send_message(chat_id= 111538566 , text= '✅ کاربر با چت آیدی {} وارد ربات شد. ✅'.format(update.message.chat_id))

    else:
        context.bot.send_message(chat_id= update.message.chat_id , text= "شما ادمین هستید و کاربر جدیدی وارد نشده !")
        

def antilink(update, context):
    list_1 = [MessageEntity.URL]
    if update.message.parse_entities(types=list_1):
        context.bot.delete_message(chat_id = update.message.chat_id , message_id= update.message.message_id)

def antilink_files(update , context):
    if update.message.caption_entities[0]['type'] == 'url':
        context.bot.delete_message(chat_id= update.message.chat_id , message_id= update.message.message_id)


token.dispatcher.add_handler(CommandHandler('start',start1))
token.dispatcher.add_handler(CommandHandler('website',website))
token.dispatcher.add_handler(CommandHandler('help' , help1))
token.dispatcher.add_handler(CommandHandler('admin' , admin))
token.dispatcher.add_handler(MessageHandler(Filters.all , antilink))
token.dispatcher.add_handler(MessageHandler(Filters.all , antilink_files))

token.start_polling()
token.idle()
