''' Mehrdad Moghadam'''

Tedad = int(input("Please Enter A Number : "))
dictionary = {}

for i in range (0,Tedad) :
    Name = input("Please Enter Your Name : ")
    Mark = int(input("Please Enter Your Mark : "))
    while Mark < 0 or Mark > 100:
        if Mark < 0 or Mark > 100:
             print("Your Mark Out Of Range !!")
        Mark = int(input("Please Enter Your Mark : "))
    dictionary[Name] = Mark


for i in dictionary.values():
    if i == 100 :
        h = open("Max.txt" , "a")
        h.write(str(i))
        h.write('\n')
        h.close()
        
    if i < 70 :
        f = open("Failed.txt" , "a")
        f.write(str(i))
        f.write('\n')
        f.close()
        
    if i >= 70 :
        g = open("Passed.txt" , "a")
        g.write(str(i))
        g.write('\n')
        g.close()

print(dictionary)
