#Mehrdad Moghadam

String = input("Enter a String: " )

String = String.lower()

String = set((String))


Seda_Dar = {"a" , "e" , "o" , "u" , "i"}

String.intersection_update(Seda_Dar)

print(String)




    
