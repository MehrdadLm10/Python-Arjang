import random

String = input("Enter a String: ")

if String == "Tas":
    x = random.randint(1,6)
    print(x)
else:
    print("Error in input")
