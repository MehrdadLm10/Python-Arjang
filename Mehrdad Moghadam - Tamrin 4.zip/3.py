X = int(input("Enter an integer Number: "))
        
if X % 2 == 0:
  print("Even")
else:
    print("Odd")
