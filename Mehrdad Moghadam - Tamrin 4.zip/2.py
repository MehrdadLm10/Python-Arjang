FName = input("Enter Your First Name: ")
LName = input("Enter Your Last Name: ")
Job = input("Enter Your Job : ")

Sam = { "FName" : FName , "Job" : Job , "LName" : LName }

FName = input("Enter Your First Name: ")
LName = input("Enter Your Last Name: ")
Job = input("Enter Your Job : ")

Brad = { "FName" : FName , "Job" : Job , "LName" : LName }

Dict_List = { "Sam" : Sam , "Brad" : Brad}

print(Dict_List)
