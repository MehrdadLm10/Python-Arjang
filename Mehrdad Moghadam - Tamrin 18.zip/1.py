'''MEHRDAD MOGHADAM'''

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import os
import time
from password import username , password

#########################################################################

driver = webdriver.Firefox(executable_path=r'D:\Barname Nevisi\Python - Arjang\geckodriver.exe')

driver.get("https://arjang.ac.ir/")

time.sleep(5)

#########################################################################

blog = driver.find_element_by_xpath('//*[@id="body-inner"]/div/div/div/div[2]/div/section/div/div/a')
blog.click()

time.sleep(3)

#########################################################################

usr = driver.find_element_by_xpath('//*[@id="block-system-wrapper"]/form/div/input')
usr.send_keys(username)
pas = driver.find_element_by_xpath('//*[@id="block-system-wrapper"]/form/div[2]/input')
pas.send_keys(password + Keys.ENTER)
