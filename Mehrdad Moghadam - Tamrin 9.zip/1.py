'''MEHRDAD MOGHADAM'''

import subprocess as Sub

sys_drive = []
drive = ["A:" , "B:" , "C:" , "D:" , "F:" , "H:" , "E:" , "G:"]
cmd = Sub.check_output("net share" , shell=True).decode()

for i in drive :
    if i in str(cmd) :
        sys_drive.append(i)

print(sys_drive)

Pasvand = input("Enter Pasvand : ")

for i in sys_drive :
    try :
        cmd = Sub.check_output("dir /S /P *. && echo > Backup"+Pasvand , shell=True)
    except  Sub.CalledProcessError:
                pass
            
print(cmd)
