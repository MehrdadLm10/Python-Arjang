'''MEHRDAD MOGHADAM'''

import subprocess as Sub

sys_drive = []
drive = ["A:" , "B:" , "C:" , "D:" , "F:" , "H:" , "E:" , "G:"]
cmd = Sub.check_output("net share" , shell=True).decode()

for i in drive :
    if i in str(cmd) :
        sys_drive.append(i)

Pasvand = input("Enter Pasvand : ")

for i in sys_drive :
    try :
        cmd = Sub.check_output("del /S *."+Pasvand , shell=True).decode()
    except  Sub.CalledProcessError:
                pass
            
print(cmd)
