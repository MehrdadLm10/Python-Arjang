''' MEHRDAD MOGHADAM '''

import subprocess as Sub

while True:
    
    cmd = Sub.check_output("start Mspaint & start Notepad" , shell=True).decode()
