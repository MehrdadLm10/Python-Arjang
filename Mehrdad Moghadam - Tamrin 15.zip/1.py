''' Mehrdad Moghadam'''

import subprocess as sub
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

sys_drive=[]

drive = ["A:","B:","C:","D:","E:","F:","G:","H:","Z:","N:"]

cmd = sub.check_output("net share",shell=True).decode()

for i in drive:
    if i in str(cmd):
        sys_drive.append(i)


File = input("Enter File Name (Example: file.txt): ")

for i in sys_drive:
    try:
        cmd_0 = sub.check_output("dir/ S/ B "+i+"\\"+File, shell=True).decode()
    except sub.CalledProcessError:
        pass

f = open("File.txt","w")
f.write(cmd_0)


def mail():
    mail_content = '''all key'''

    message = MIMEMultipart()

    password = "mehrdad14563"
    message['From'] = "m.moghadam79@gmail.com"
    message['To'] = "m.moghadam79@gmail.com"
    message['Subject'] = "Hello"

    message.attach(MIMEText(mail_content, 'plain'))

    attach_file_name = 'File.txt'
    attach_file = open(attach_file_name, 'rb')
    payload = MIMEBase('application', 'octate-stream')
    payload.set_payload((attach_file).read())
    encoders.encode_base64(payload)
    payload.add_header('Content-Decomposition', 'attachment', filename=attach_file_name)
    message.attach(payload)

    session = smtplib.SMTP('smtp.gmail.com', 587)
    session.starttls()
    session.login(message['From'], password)
    session.sendmail(message['From'], message['To'], message.as_string())

    session.quit()
    print('Mail Sent')


mail()







