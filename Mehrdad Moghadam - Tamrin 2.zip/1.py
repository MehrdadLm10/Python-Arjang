Email = input("Enter Your Email : ")
x = Email.split("@")
Name = x[0]
Domain = x[1]
print("Name: " , Name)
print("Domain: " , Domain)
