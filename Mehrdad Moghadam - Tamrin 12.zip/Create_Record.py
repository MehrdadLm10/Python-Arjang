import mysql.connector

mydb = mysql.connector.connect(host="localhost" , user="root" , password="Mehrdad1" , database="Mehrdad")

Cursor = mydb.cursor()
sql = "INSERT INTO PROFILE (name , age) VALUES (%s , %s)"
val = [('Mehrdad' , '20') ,
       ('Ali' , '30') ,
       ('Hasan' , '15') ,
       ('Reza' , '45')
]

Cursor.executemany(sql , val)

mydb.commit()
