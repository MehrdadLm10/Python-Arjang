import mysql.connector

mydb = mysql.connector.connect(host="localhost" , user="root" , password="Mehrdad1" , database = "Mehrdad")

Cursor = mydb.cursor()
Cursor.execute("DROP TABLE PROFILE")

mydb.commit()
