#Mehrdad Moghadam

List = ["C++" , "Ruby" , "Python" , "Java"]

for i in List:
    if i == "Python" :
        break
    print(i)
