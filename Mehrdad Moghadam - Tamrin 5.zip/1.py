import datetime
X = datetime.datetime.today().minute

Baghimandeh = X % 7
print(Baghimandeh)

if Baghimandeh%2==0:
    print("Even")
else:
    print("Odd")