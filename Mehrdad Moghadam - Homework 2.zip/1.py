List = ["Python" , "C++" , "Ruby" , "Java" , "PHP"]

#Make List 2
x = List.pop()
y = List.pop()
List2 = [x , y]

#Make List 3
a = List.pop()
b = List.pop()
c = List.pop()
List3 = [a,b,c]

#Print

print("List : " , List)
print("List 2 : " , List2)
print("List 3 : " , List3)
