List = [True , False , "True" , None , "True" , 45.5 , 40 , "True" , 1+2j]

#Remove "True"
List.remove("True")

#POP
List.pop()
List.pop()

#Print
print("List: " , List)
