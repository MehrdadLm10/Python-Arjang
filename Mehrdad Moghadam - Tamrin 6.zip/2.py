''' MEHRDAD MOGHADAM '''

class Number:
    def __init__ (self , number1 , number2 ) :
        self.number1 = number1
        self.number2 = number2

    def Sum (self) :
        return self.number1 + self.number2

    def Mul (self) :
        return self.number1 * self.number2

    def Sub (self) :
        return self.number1 - self.number2

    def Div (self) :
        return self.number1 / self.number2


My_Number = Number(2 , 6)

print(" SUM IS : " , My_Number.Sum())
print(" SUB IS : " , My_Number.Sub())
print(" MUL IS : " , My_Number.Mul())
print(" DIV IS : " , My_Number.Div())
