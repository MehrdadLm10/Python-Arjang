''' MEHRDAD MOGHADAM '''


class Name  :
    def __init__ (self , X=0 , Counter=1 ) :
        self.X = X
        self.Counter = Counter

    def Count(self) :
        self.X += self.Counter
        return self.X

    def __repr__(self):
        return repr(self.X)

ob1 = Name()
print(ob1.Count())
print(ob1.Count())
print(ob1.Count())
print(ob1.Count())
print(ob1.Count())
print(" Instantaneous value : " , repr(ob1))
print(ob1.Count())

print("-------------------------------------------------------")

ob2 = Name(10,5)
print(ob2.Count())
print(ob2.Count())
print(ob2.Count())
print(" Instantaneous value : " , repr(ob2))
print(ob2.Count())
