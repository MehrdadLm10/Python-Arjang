List = [False , True , 5 , "5" , "Ali Norouzi" , 25.5 ]
print("Type: " , type(List))
print("Lenght: " , len(List))

print(" ")
List.extend(["Python" , "Programming"])
List.insert(-1 , "Python Enginnering")
print(List)
