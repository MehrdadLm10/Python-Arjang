List = [True , False , "True" , None , 30 , 30.5 , 2+3j]

List.remove("True")

del List[-2:]

List.clear()

del List
