List = ("Benz" , "BMW" , "Porsche")
List = list(List)
List[1] = "Ford"
List = tuple(List)

print("Type: " , type(List))
print(List)
