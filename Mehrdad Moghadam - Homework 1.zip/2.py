x = int(input("Enter A Number From 0 To 40: "))

Num = [1,2,5,8,10,14,16,19,22,25,27,30,33,38,40]

print("Is There A Number In The List?? " , x in Num) 

