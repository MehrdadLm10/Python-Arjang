a = int(input("Enter a Number For a in Delta: "))
b = int(input("Enter a Number For b in Delta: "))
c = int(input("Enter a Number For c in Delta: "))

Delta = (b**2) - (4*a*c)

print("Delta is: " , Delta)
