''' MEHRDAD MOGHADA'''

from winreg import *

def Disable_USB() :
    Keyval = r'SYSTEM\CurrentControlSet\Services\USBSTOR'
    try :
        key = OpneKey(HKEY_LOCAL_MACHINE,Keyval,0,KEY_ALL_ACCESS)
    except :
        key = CreateKey(HKEY_LOCAL_MACHINE,Keyval)

    SetValueEx(key , "start" , 0 , REG_DWORD , 4)
    CloseKey(key)

def Disable_CDROM() :
    Keyval = r'SYSTEM\CurrentcontrolSet\Services\cdrom'
    try :
        key = OpenKey(HKEY_LOCAL_MACHINE,Keyval,0,KEY_ALL_ACCESS)
    except :
        key = CreateKey(HKEY_LOCAL_MACHINE,Keyval)

    SetValueEx(key , "start" , 0 , REG_DWORD , 4)
    CloseKey(key)

Disable_USB()
Disable_CDROM()
