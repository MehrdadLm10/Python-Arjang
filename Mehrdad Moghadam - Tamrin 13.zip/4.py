''' MEHRDAD MOGHADAM '''

from tkinter import *
import subprocess as Sub

win = Tk()


def Open_Chrome() :
    Chrome = Sub.check_output("start chrome" , shell=True).decode()

def Open_Paint() :
    Paint = Sub.check_output("start MSpaint" , shell=True).decode()

def Open_FireFox() :
    FireFOx = Sub.check_output("start firefox" , shell=True).decode()

def Open_Notepad() :
    Notepad = Sub.check_output("start notepad" , shell=True).decode()



B = Button(win , text = "Open Chrome!!" , fg="white" , bg="black" , command=Open_Chrome)
B.grid()

B = Button(win , text = "Open Paint!!" , fg="white" , bg="black" , command=Open_Paint)
B.grid()

B = Button(win , text = "Open FireFox!!" , fg="white" , bg="black" , command=Open_FireFox)
B.grid()

B = Button(win , text = "Open Notepad!!" , fg="white" , bg="black" , command=Open_Notepad)
B.grid()


win.mainloop()
