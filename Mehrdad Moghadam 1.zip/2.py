#Mehrdad Moghadam

#Input And Append In List 
Num = float(input("Enter Number1 : "))
list = []
list.append(Num)
Num = float(input("Enter Number2 : "))
list.append(Num)
Num = float(input("Enter Number3 : "))
list.append(Num)
Num = float(input("Enter Number4 : "))
list.append(Num)
Num = float(input("Enter Number5 : "))
list.append(Num)

#Sort
list.sort()
list.reverse()
print(list)

print("-------------------------------------------------")

#Average Of Numbers
Sum = list[0]+list[1]+list[2]+list[3]+list[4]
Average = Sum/len(list)
print("Average is : %0.2f " %Average)

print("-------------------------------------------------")


#Max - Min
Max = list[0]
Min = list[-1]
print("The Largest Number Is : " , Max)
print("The Smallest Number Is : " , Min)

print("-------------------------------------------------")

#Tuple
Tuple = tuple((list))
print(Tuple)
