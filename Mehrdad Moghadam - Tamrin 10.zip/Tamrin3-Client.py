from socket import *

s = socket(2,1)
s.connect(("127.0.0.1",4444))
print("connected")


f = open("screen1.png","rb")
data = memoryview(f.read())
s.send(str(len(data)).encode())
print(s.recv(1024))
s.send(data)
f.close()

s.close()
