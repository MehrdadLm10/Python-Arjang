''' MEHRDAD MOGHADAM '''

from tkinter import *
import subprocess as Sub

win = Tk()
win.geometry("800x800")

def ipconfig():
    ip_config = Sub.check_output("ipconfig", shell=True).decode()
    l2.configure(text = ip_config)


b = Button(win, text="Click", bg="black", fg="white", command=ipconfig)
b.grid()

l2 = Label(win , text="")
l2.grid()

win.mainloop()
