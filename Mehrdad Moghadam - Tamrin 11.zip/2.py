''' MEHRDAD MOGHADAM '''

from tkinter import *
import subprocess as Sub

win = Tk()


def First_Second_cmd() :
    First_Code = n.get()
    First = Sub.check_output(First_Code , shell=True).decode()
    l3.configure(text = First)
    
    Second_Code = m.get()
    Second = Sub.check_output(Second_Code , shell=True).decode()
    l4.configure(text = Second)

n = StringVar()
l1 = Label(win , text="Write First Code In Cmd : ")
l1.grid()
x = Entry(win , width=20 , textvariable = n)
x.grid()

m = StringVar()
l2 = Label(win , text="Write Second Code In Cmd : ")
l2.grid()
y = Entry(win , width=20 , textvariable = m)
y.grid()

B = Button(win , text = "Click!!" , fg="white" , bg="black" , command=First_Second_cmd)
B.grid()

l3 = Label(win , text="")
l3.grid()

l4 = Label(win , text="")
l4.grid()

win.mainloop()
